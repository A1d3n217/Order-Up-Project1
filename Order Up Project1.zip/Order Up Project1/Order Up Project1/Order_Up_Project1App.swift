//
//  Order_Up_Project1App.swift
//  Order Up Project1
//
//  Created by Wood, Aiden - Student on 9/10/24.
//

import SwiftUI

@main
struct Order_Up_Project1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
